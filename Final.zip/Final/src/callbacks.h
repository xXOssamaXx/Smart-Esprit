#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button3_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_ajout_clicked               (GtkButton      *button,
                                        gpointer         user_data);

void
on_button6_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_save_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_ajout_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button9_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button10_rech_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_gen_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_close_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_login_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
