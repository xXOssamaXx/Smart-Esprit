#include <gtk/gtk.h> 

typedef struct
{
	char id[50];
	char Pw[50];
}login;



typedef struct
{
	char jour[20];
	int  temps;
	char entree[50];
	char plat_principale[50];
	char dessert[50];
	int dechets;
}menu;


void afficher(GtkWidget *liste);

void ajout_menu(menu m);

void supprimer_menu(char jour[],int temps);

menu rechercher_menu(char nom_fichier[],char jour[],int temps);

void modifier_menu(char nom_fichier[],char jour[],int temps);

menu meilleur_menu(char nom_fichier[]);
