#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"fonction.h"
#include <gtk/gtk.h>
enum
{
	EJOUR,
	ETEMPS,
	EENTREE,
	EPLAT,
	EDESSERT,
	EDECHETS,
	COLUMNS
};




int verif(menu m,char nom_fichier[])
{
FILE *f=NULL;
        char ch1[200],ch2[200],ch3[200],ch4[200];
        int a,b,test=1;
        strcpy(nom_fichier,"menu.txt");
        f=fopen(nom_fichier,"r");
        if(f!=NULL)
        {

            while(fscanf(f,"%s %d %s %s %s %d\n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {
                 if (strcmp(m.jour,ch1)==0&&m.temps==a&&strcmp(m.entree,ch2)==0&&strcmp(m.plat_principale,ch3)==0&&strcmp(m.dessert,ch4)==0&&m.dechets==b)
{
test=0;
}
            }
        }

        fclose(f);
return test;
    }




void ajout_menu(menu m)
{
    FILE *f;
/*
do
{
    printf(" donner le jour,le temps,l'entree,le plat principale,le dessert et le dechets\n");
    scanf("%s %d %s %s %s %d",m.jour,&m.temps,m.menu.entree,m.menu.plat_principale,m.menu.dessert,&m.dechets );
}while(verif(m,nom_fichier)==0);
    strcpy(nom_fichier,"menu.txt");
    f=fopen(nom_fichier,"a");
    fprintf(f,"%s %d %s %s %s %d \n",m.jour,m.temps,m.entree,m.plat_principale,m.dessert,m.dechets  );
    fclose(f);*/
f=fopen("menu.txt","a+");
if(verif(m,"menu.txt")==0)
{
fprintf(f,"%s %d %s %s %s %d \n", m.jour, m.temps, m.entree, m.plat_principale, m.dessert, m.dechets);
fclose(f);
}
}



void supprimer_menu(char jour[],int temps)
    {
        FILE *f=NULL;
        FILE *s=NULL;
        char ch1[200],ch2[200],ch3[200],ch4[200];
        int a,b,x,test=0;
        f=fopen("menu.txt","r");
        s=fopen("sup.txt","a");
        if(f!=NULL)
        {//if
            while(fscanf(f,"%s %d %s %s %s %d \n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {//while
		if (strcmp(ch1,jour)!=0||a!=temps)
	{
                    fprintf(s,"%s %d %s %s %s %d \n",ch1,a,ch2,ch3,ch4,b);
	}
		

            }//while
        }//if

        fclose(f);
        fclose(s);
        remove("menu.txt");
        rename("sup.txt","menu.txt");

    }




void modifier_menu(char nom_fichier[],char jour[],int temps)
     {
        FILE *f=NULL;
        FILE *mo=NULL;
        menu m;
        char ch1[200],ch2[200],ch3[200],ch4[200];
        int a,b,test=0;
        strcpy(nom_fichier,"menu.txt");
        f=fopen(nom_fichier,"r");
        mo=fopen("mod.txt","a");
        if(f!=NULL)
        {
            while(fscanf(f,"%s %d %s %s %s %d \n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {

                if (strcmp(ch1,jour)!=0||a!=temps)
                {
                    fprintf(mo,"%s %d %s %s %s %d \n",ch1,a,ch2,ch3,ch4,b);
                }
                else
                {
		   test=1;
 		   printf(" donner le jour,le temps,l'entree,le plat principale,le dessert et le dechets\n");
                   scanf("%s %d %s %s %s %d",m.jour,&m.temps,m.entree,m.plat_principale,m.dessert,&m.dechets );
                   fprintf(mo,"%s %d %s %s %s %d\n",m.jour,m.temps,m.dessert,m.entree,m.plat_principale,m.dechets );
                }
            }
        }

        fclose(f);
        fclose(mo);
        remove(nom_fichier);
        rename("mod.txt",nom_fichier);
if (test==0)
{
printf("le menu n'existe pas\n");
}
     }





menu rechercher_menu(char nom_fichier[],char jour[],int temps)
    {
        FILE *f=NULL;
        menu m;
        char ch1[200],ch2[200],ch3[200],ch4[200];
        int a,b;
        f=fopen(nom_fichier,"r");
        if(f!=NULL)
        {
            while(fscanf(f,"%s %d %s %s %s %d \n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)



                if (strcmp(ch1,jour)==0&&a==temps)
                {
                    strcpy(m.jour,ch1);
                    m.temps=a;
                    strcpy(m.entree,ch2);
                    strcpy(m.plat_principale,ch3);
                    strcpy(m.dessert,ch4);
                    m.dechets=b;
            }
        }
         fclose(f);
         return m;

    }






void afficher(GtkWidget *liste){


	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char jour[20];
	int  temps;
	char entree[50];
	char plat_principale[50];
	char dessert[50];
	int dechets;
	store =NULL;

	FILE *f;

	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text", EJOUR, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("temps", renderer, "text", ETEMPS, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("entree", renderer, "text", EENTREE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("plat_principale", renderer, "text", EPLAT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("dessert", renderer, "text", EDESSERT, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("dechets", renderer, "text", EDECHETS, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		store = gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);

		f = fopen("menu.txt", "r");

		if (f == NULL)
		{
			return;
		}
		else
		{
		f = fopen("menu.txt", "a+");
			while(fscanf(f,"%s %d %s %s %s %d\n",jour,&temps,entree,plat_principale,dessert,&dechets)!=EOF)
		{
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, EJOUR, jour, ETEMPS, temps, EENTREE, entree, EPLAT, plat_principale, EDESSERT,  dessert, EDECHETS, dechets, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
		g_object_unref (store);
	}
	}
}

/*       
 FILE *f=NULL;
        char ch1[200],ch2[200],ch3[200],ch4[200];
        int a,b;
        strcpy(nom_fichier,"menu.txt");
        f=fopen(nom_fichier,"r");
        if(f!=NULL)
        {

            while(fscanf(f,"%s %d %s %s %s %d\n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {
                 printf("%s %d %s %s %s %d\n",ch1,a,ch2,ch3,ch4,b);
            }
        }

        fclose(f);
*/






    





menu meilleur_menu(char nom_fichier[])
    {
        FILE *f=NULL;
        menu m;
        char ch1[200],ch2[200],ch3[200],ch4[200],jour[200];
        int a,b,cmp=100000,temps;
        strcpy(nom_fichier,"menu.txt");
        f=fopen(nom_fichier,"r");
        if(f!=NULL)
        {

            while(fscanf(f,"%s %d %s %s %s %d \n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {
                 if(cmp>b)
                 {
                    cmp=b;
                    strcpy(jour,ch1);
                    temps=a;
                 }
            }
            fclose(f);
            f=fopen(nom_fichier,"r");
            while(fscanf(f,"%s %d %s %s %s %d \n",ch1,&a,ch2,ch3,ch4,&b)!=EOF)
            {
                 if(strcmp(ch1,jour)==0&&a==temps)
                    {
                    strcpy(m.jour,ch1);
                    m.temps=a;
                    strcpy(m.entree,ch2);
                    strcpy(m.plat_principale,ch3);
                    strcpy(m.dessert,ch4);
                    m.dechets=b;
                    }

            }
        }

        fclose(f);
        return m;
    }
