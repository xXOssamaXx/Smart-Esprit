#ifdef HAVE_CONFIG_H
#include<config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int x;
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* jour;
gchar* temps;
gchar* entree;
gchar* plat_principale;
gchar* dessert;
gchar* dechets;
menu m;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path)) {

gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0, &jour, 1,&temps,2, &entree, 3, &plat_principale, 4, &dessert, 5, &dechets, -1);

strcpy(m.jour, jour);
strcpy(m.temps, temps);
strcpy(m.entree, entree);
strcpy(m.plat_principale, plat_principale);
strcpy(m.dessert, dessert);
strcpy(m.dechets, dechets);
afficher(treeview);
}
}


void
on_button3_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmodif;
windowmodif=create_window4_modif();
gtk_widget_show (windowmodif);
}


void
on_button4_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char nom_fichier;
strcpy(nom_fichier,"menu.txt");
char jour; int temps;
supprimer_menu(jour, temps);
}


void
on_button2_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

	GtkWidget *souma;
	souma = create_window3_ajout();
	gtk_widget_show (souma);

}


void
on_button6_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowdash;
windowdash=create_window5_dashboard();
gtk_widget_show (windowdash);
}


void
on_button5_save_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowdash;
windowdash=create_window5_dashboard();
gtk_widget_show (windowdash);
}


void
on_button7_ajout_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu m;
GtkWidget *comboboxentry1;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
GtkWidget *fenetre_ajout;
int jour;

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

input1=lookup_widget(objet,"jour");
input2=lookup_widget(objet,"temps");
input3=lookup_widget(objet,"entree");
input4=lookup_widget(objet,"plat_principale");
input5=lookup_widget(objet,"dessert");
input6=lookup_widget(objet,"dechets");
comboboxentry1=lookup_widget(objet,"comboboxentry1");
if (strcmp("Lundi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==0)
jour=1;
else 
 if(strcmp("Mardi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==1)
jour=2;
else 
 if(strcmp("Mercredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==2)
jour=3;
else 
 if(strcmp("Jeudi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==3)
jour=4;
else 
 if(strcmp("Vendredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==4)
jour=5;
else 
 if(strcmp("Samedi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==5)
jour=6;
else 
jour=7;

strcpy(m.jour, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(m.temps, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(m.entree, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(m.plat_principale, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(m.dessert, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(m.dechets, gtk_entry_get_text(GTK_ENTRY(input6)));

ajout_menu(m);



}
void
on_button8_clicked               (GtkWidget       *objet,
                                  gpointer         user_data)
{
menu m;
GtkWidget *comboboxentry1;
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
GtkWidget *fenetre_ajout;
int jour;
fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

input1=lookup_widget(objet,"jour");
input2=lookup_widget(objet,"temps");
input3=lookup_widget(objet,"entree");
input4=lookup_widget(objet,"plat_principale");
input5=lookup_widget(objet,"dessert");
input6=lookup_widget(objet,"dechets");
comboboxentry1=lookup_widget(objet,"comboboxentry1");
if (strcmp("Lundi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==0)
jour=1;
else 
 if(strcmp("Mardi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==1)
jour=2;
else 
 if(strcmp("Mercredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==2)
jour=3;
else 
 if(strcmp("Jeudi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==3)
jour=4;
else 
 if(strcmp("Vendredi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==4)
jour=5;
else 
 if(strcmp("Samedi",gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)))==5)
jour=6;
else 
jour=7;

strcpy(m.jour, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(m.temps, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(m.entree, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(m.plat_principale, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(m.dessert, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(m.dechets, gtk_entry_get_text(GTK_ENTRY(input6)));

ajout_menu(m);

}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{x=1;}

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=3;}
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=4;}
}


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=5;}
}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=6;}
}



void
on_button9_aff_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout;
	GtkWidget *fenetre_afficher;
	GtkWidget *treeview1;

	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

	gtk_widget_destroy(fenetre_ajout);
	fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
	fenetre_afficher = create_window2_aff();

	gtk_widget_show(fenetre_afficher);

	treeview1=lookup_widget(fenetre_afficher,"treeview1");

	afficher(treeview1);

}



void
on_button10_rech_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrech;
windowrech=create_window6_rech();
gtk_widget_show (windowrech);
}


void
on_button11_gen_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button12_close_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowdash;
windowdash=create_window5_dashboard();
gtk_widget_show (windowdash);
}


void
on_button1_login_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username,*password,*windowdash;
char user[20];
char pasw[20];
int trouve;
username = lookup_widget (button, "entry3_log");
password = lookup_widget (button, "entry4_Pw");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);

if(trouve==1)
{
windowdash=create_window5_dashboard();
gtk_widget_show (windowdash);
}
}

